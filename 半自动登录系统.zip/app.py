from flask import Flask, jsonify
from flask_cors import cross_origin
app = Flask(__name__)

import re

lines = []
with open("accounts.txt", "r") as fp:
    lines = fp.readlines()
    lines = [re.split("[^a-zA-Z0-9\.\@]+", x[4:].strip()) for x in lines]
count = 0
print("n accounts: " + str(len(lines)))
@app.route('/account')
@cross_origin()
def get_account():
    global count
    if count >= len(lines):
        print("Run out of accounts!")
        return "404"
    result = {
        "email": lines[count][0],
        "password": lines[count][1],
        "email2": lines[count][2]
    }
    count += 1
    return jsonify(result)


if __name__ == '__main__':
    app.run(host='127.0.0.1', port=5001)
